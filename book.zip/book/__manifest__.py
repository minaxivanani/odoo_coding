{
  'name':'book library',
  'category':'Sales',
  'application':True,

  'data':[

      'views/book_menu.xml',
      'security/ir.model.access.csv',
      'views/book_view.xml',
  ]


}