{
  'name' : 'Gvp library',
  'category' : 'Sales',
  'application': True,
  'data':[

           'views/library_menu.xml',
           'security/ir.model.access.csv',
           
    ],
  

}